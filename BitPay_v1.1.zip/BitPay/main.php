<?php namespace App\Plugins\BitPay;

require_once __DIR__ . '/lib/vendor/autoload.php';

use App\Http\Controllers\Controller;
use App\Models\Plugin;
use App\Services\AmountService;
use App\Services\Util;
use Carbon\Carbon;
use Event;
use Exception;
use Input;
use Redirect;
use Route;
use Symfony\Component\Translation\Translator;
use Symfony\Component\Translation\Loader\ArrayLoader;
use Illuminate\Http\Request;
use App\Models\Log;
use App\Models\Product;
use App\Models\ProductTransaction;
use App\Models\Transaction;
use App\Models\TransactionMetadata;
use App\Models\TransactionUpdate;
use App\Models\User;
use Validator;


class BitPayController extends Controller {

    private $request;

    public $ins_id;
    public $ins_url;
    public $ins_posData;
    public $ins_status;
    public $ins_btcPrice;
    public $ins_price;
    public $ins_currency;
    public $ins_invoiceTime;
    public $ins_expirationTime;
    public $ins_currentTime;
    public $ins_btcPaid;
    public $ins_rate;
    public $ins_exceptionStatus;
    public $ins_bitpay;
    public $ins_all;

    public $order_invoice_id;
    public $order_product_id;
    public $order_customer_name;
    public $order_customer_email;
    public $order_total;
    public $order_currency;
    public $order_created_at;

    // https://bitpay.com/docs/invoice-states
    const INVOICE_STATUS_NEW = 'new';
    const INVOICE_STATUS_PAID= 'paid';
    const INVOICE_STATUS_CONFIRMED = 'confirmed';
    const INVOICE_STATUS_COMPLETE = 'complete';
    const INVOICE_STATUS_EXPIRED = 'expired';
    const INVOICE_STATUS_INVALID = 'invalid';

    public $private_key;
    public $public_key;
    public $token;
    public $mode;
    public $client_error_message = 'Sorry, something went wrong.';

    public function __construct()
    {
        // first time only, generate keys
        if(!Options::get('public_key')){

            $private = new \Bitpay\PrivateKey('/tmp/private.key');
            $public  = new \Bitpay\PublicKey('/tmp/public.key');

            // Generate Private Key values
            $private->generate();

            // Generate Public Key values
            $public->setPrivateKey($private);
            $public->generate();

            Options::update('public_key', serialize($public));
            Options::update('private_key', serialize($private));
        }

        $this->public_key = unserialize(Options::get('public_key'));
        $this->private_key = unserialize(Options::get('private_key'));
        $this->mode = Options::get('mode');

        $this->token = Options::get('token') ? unserialize(Options::get('token')) : false;

        return parent::__construct();
    }

    public function setup()
    {
        if(APP_VERSION < Setup::$minimum_version) {
            return view(basename(__DIR__) . '/views/requirements');
        };

        return view(basename(__DIR__).'/views/setup')->with([
            'options' => Options::getAll(),
        ]);
    }

    public function update()
    {
        $rules = [
            'mode' => 'required',
            'currency' => 'required',
            'pairing_code' => 'required',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('bitpay')
                ->withErrors($validator)
                ->withInput();
        } else {

            if(Options::get('pairing_code') != Input::get('pairing_code')
                || Options::get('mode') != Input::get('mode')) {
                // paring code has been changed, validate token
                $this->mode = Input::get('mode');
                $this->token = null;
                $ret = $this->updateToken(Input::get('pairing_code'));
                if (!$ret) {
                    return Redirect::to('bitpay')
                        ->withErrors('Unable to create Token. Please update your Pairing Code and try again.')
                        ->withInput();
                }
            }

            try {
                Options::update('mode', Input::get('mode'));
                Options::update('currency', Input::get('currency'));
                Options::update('pairing_code', Input::get('pairing_code'));

            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to('bitpay')
                    ->withErrors($e->getMessage())
                    ->withInput();
            }

            flash()->success(trans('app.success'));
            return Redirect::to('bitpay');

        }
    }

    public function getBitPayClient()
    {
        $network = ($this->mode == 'live' ? new \Bitpay\Network\Livenet() : new \Bitpay\Network\Testnet());

        $adapter = new \Bitpay\Client\Adapter\CurlAdapter();

        $client = new \Bitpay\Client\Client();

        $client->setPrivateKey($this->private_key);
        $client->setPublicKey($this->public_key);
        $client->setNetwork($network);
        $client->setAdapter($adapter);

        if($this->token) {
            $client->setToken($this->token);
        }

        return $client;
    }

    public function updateToken($pairing_code)
    {
        $client = $this->getBitPayClient();

        $sin = \Bitpay\SinKey::create()->setPublicKey($this->public_key)->generate();

        try {
            $token = $client->createToken(
                array(
                    'pairingCode' => $pairing_code,
                    'label'       => 'DuckSell Token '.$pairing_code,
                    'id'          => (string) $sin,
                )
            );
        } catch (\Exception $e) {
            Log::writeException($e);
            return false;
        }

        Options::update('token', serialize($token));

        return true;
    }

    public function placeOrder($product_id)
    {
        $product = Product::findOrFail($product_id);

        return view(basename(__DIR__).'/views/order')->with([
            'item' => $product->name,
            'price' => AmountService::displayAmount($product->getPrice(), Options::get('currency')),
        ]);

    }

    public function placeOrderSubmit($product_id)
    {
        $rules = [
            'name' => 'required',
            'email' => 'required|email',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('purchase_bitpay/'.$product_id)
                ->withErrors($validator)
                ->withInput();
        }

        $customer_name = Input::get('name');
        $customer_email = Input::get('email');

        $OrderModel = new OrderModel();

        $product = Product::findOrFail($product_id);
        $currency = Options::get('currency');
        $client = $this->getBitPayClient();
        $price = $product->getPrice() / 100;

        if(!$this->token) {
            Log::write('bitpay token error', 'no token', true, Log::TYPE_CRITICAL);
            return $this->client_error_message;
        }

        $item = new \Bitpay\Item();
        $item
            ->setCode($product->id)
            ->setDescription($product->name)
            ->setPrice($price);

        $invoice = new \Bitpay\Invoice();
        $invoice->setItem($item);
        $invoice->setCurrency(new \Bitpay\Currency($currency));
        $invoice->setNotificationUrl('https://'.Util::stripProtocol(url('bitpayipn')));

        try {
            $client->createInvoice($invoice);
        } catch (\Exception $e) {
            Log::write('bitpay error', $e->getMessage(), true, Log::TYPE_CRITICAL);
            return $this->client_error_message;
        }

        $invoice_id = $invoice->getId();
        $OrderModel->createOrder($invoice_id, $product->id, $price, $currency, $customer_name, $customer_email);

        return Redirect::to($invoice->getUrl());
    }

    public function callback(Request $request)
    {
        $Transaction = new Transaction();

        $this->request = $request;

        if(!$this->buildIns()) {
            return;
        }

        if(!$this->buildOrder($this->getSaleId())) {
            return;
        }

        if($Transaction->getTransactionByExternalSaleId($this->getSaleId())) {
            // transaction exists? update only
            $this->setTransactionStatus($this->getSaleId(), $this->getStatusIdBasedOnInvoice(), 'trx_update_invoice_status');
        } else {
            $this->createOrder();
        }

        return;
    }

    private function setTransactionStatus($transaction_id, $status_id, $description)
    {
        $Transaction = new Transaction();
        $TransactionUpdate = new TransactionUpdate();

        $transaction = $Transaction->getTransactionByExternalSaleId($transaction_id);

        if(!$transaction) {
            Log::write('log_cannot_update_transaction', $transaction_id);
            return false;
        }

        $Transaction->setStatus($transaction->id, $status_id);
        $TransactionUpdate->updateTransaction($transaction->id, $description, Setup::$plugin_name, 'transaction_status_'.$status_id);

        return true;
    }

    private function createOrder()
    {
        $User = new User();
        $Product = new Product();
        $Transaction = new Transaction();
        $ProductTransaction = new ProductTransaction();
        $TransactionUpdate = new TransactionUpdate();
        $TransactionMetadata = new TransactionMetadata();

        // get existing or create new customer
        $customer = $User->getOrCreateCustomer($this->getCustomerEmail(), $this->getCustomerName(), $this->getCustomerDetails(), $this->getCustomerMetaData());
        if(!$customer) {
            Log::write('log_cannot_create_customer', $this->getCustomerEmail(), true, Log::TYPE_CRITICAL);
            return false;
        }

        // in case this is returning customer, update details with fresh set
        $customer->details = $this->getCustomerDetails();
        $customer->save();

        // first check all products in request and prepare them
        $product = $Product->find($this->order_product_id);

        if(!$product) {
            Log::write('log_request_failed_no_items', $this->getRawInsString());
            return false;
        }

        if($Transaction->getTransactionByExternalSaleId($this->getSaleId())) {
            Log::write('log_cannot_create_order_exist', $this->getSaleId(), true, Log::TYPE_CRITICAL);
            return false;
        }

        // create transaction
        $transaction = $Transaction->createTransaction(Setup::$plugin_name, $customer->id, $this->getInvoiceAmount(new AmountService()), $this->getStatusIdBasedOnInvoice(), $this->getSaleId());
        if(!$transaction) {
            Log::write('log_cannot_create_transaction', $this->getRawInsString(), true, Log::TYPE_CRITICAL);
            return false;
        }

        // add metadata
        $TransactionMetadata->addMetadata($transaction->id, $this->getTransactionMetaData());

        // set initial statuses
        $TransactionUpdate->updateTransaction($transaction->id, 'trx_update_invoice_status', Setup::$plugin_name, $this->getInvoiceRawStatus());

        if($this->getInvoiceExceptionStatus()) {
            Log::write('BitPay: '.$this->getInvoiceExceptionStatus(), $this->getInvoiceExceptionStatus(), true);
        }

        // add product
        $ProductTransaction->addProductToTransaction($product->id, $this->getInvoiceAmount(new AmountService()), $transaction->id);

        $Transaction->sendPurchaseInformationEmail($transaction->hash);

        return $transaction;
    }

    private function getRawInsString()
    {
        return $this->ins_all;
    }

    private function getInvoiceAmount(AmountService $amount)
    {
        $amount->setProcessorCurrency($this->order_currency);
        $amount->setProcessorAmount($this->order_total);

        $amount->setListedCurrency($this->order_currency);
        $amount->setListedAmount($this->order_total);

        $amount->setCustomerCurrency($this->ins_currency);
        $amount->setCustomerAmount($this->ins_price);

        return $amount;
    }

    private function getInvoiceRawStatus()
    {
        // invoice status string: approved, pending, deposited, or declined
        return $this->ins_status;
    }

    private function getInvoiceExceptionStatus()
    {
        $status_id = false;

        switch ($this->ins_exceptionStatus) {

            case 'paidPartial':
                $status_id = 'Amount paid is less than the amount expected!';
                break;

            case 'paidOver':
                $status_id = 'Amount paid is greater than the amount expected!';
                break;

            case 'paidLate':
                $status_id = 'The invoice was paid outside the payment window.';
                break;

        }

        return $status_id;
    }

    private function getCustomerEmail()
    {
        return $this->order_customer_email;
    }

    private function getCustomerName()
    {
        return $this->order_customer_name;
    }

    private function getCustomerDetails()
    {
        return '';
    }

    public function getStatusIdBasedOnInvoice()
    {
        $Transactions = new Transaction();

        switch ($this->ins_status) {

            case self::INVOICE_STATUS_COMPLETE:
            case self::INVOICE_STATUS_CONFIRMED:
            case self::INVOICE_STATUS_PAID:
                $status_id = $Transactions::STATUS_APPROVED;
                break;

            case self::INVOICE_STATUS_NEW:
                $status_id = $Transactions::STATUS_PENDING;
                break;

            case self::INVOICE_STATUS_EXPIRED:
                $status_id = $Transactions::STATUS_EXPIRED;
                break;

            case self::INVOICE_STATUS_INVALID:
                $status_id = $Transactions::STATUS_CANCELED;
                break;

            default:
                $status_id = $Transactions::STATUS_CANCELED;
                break;
        }

        return $status_id;
    }

    private function getCustomerMetaData()
    {
        $metadata = [];

        $metadata['name'] = $this->order_customer_name;
        $metadata['email'] = $this->order_customer_name;

        return $metadata;
    }

    private function getTransactionMetaData()
    {
        $metadata = [];

        // mandatory fields (translatable keys)
        $metadata['external_sale_id'] = $this->ins_id;
        $metadata['timestamp'] = $this->ins_currentTime;
        $metadata['sale_date_placed'] = $this->ins_invoiceTime;
        $metadata['expiration_time'] = $this->ins_expirationTime;
        $metadata['processor_amount'] = $this->ins_btcPrice;
        $metadata['invoice_url'] = $this->ins_url;
        $metadata['btcPaid'] = $this->ins_btcPaid;
        $metadata['exchange_rate'] = $this->ins_rate;
        $metadata['exception_status'] = $this->ins_exceptionStatus;

        return $metadata;
    }

    private function getSaleId()
    {
        return $this->ins_id;
    }

    private function buildIns()
    {
        /*
         * BitPay INS
         * https://bitpay.com/docs/invoice-callbacks
         */

        $sample = '
        {
          "id": "123BitPayInvoiceID",
          "url": "https://bitpay.com/invoice?id=123BitPayInvoiceID",
          "posData": "{\"paymentID\":\"123PAYMENTID\",\"orderID\":\"123ORDERID\"}",
          "status": "paid",
          "btcPrice": "0.0512",
          "price": 29.14,
          "currency": "USD",
          "invoiceTime": 1407881291063,
          "expirationTime": 1407882191063,
          "currentTime": 1407882058099,
          "btcPaid": "0.0512",
          "rate": 568.69,
          "exceptionStatus": false,
          "bitpay":
            {
              "id": "123BitPayInvoiceID",
              "url": "https://bitpay.com/invoice?id=123BitPayInvoiceID",
              "posData": "{\"paymentID\":\"123PAYMENTID\",\"orderID\":\"123ORDERID\"}",
              "status": "confirmed",
              "btcPrice": "0.0512",
              "price": 29.14,
              "currency": "USD",
              "invoiceTime": 1407881291063,
              "expirationTime": 1407882191063,
              "currentTime": 1407882058099,
              "btcPaid": "0.0512",
              "rate": 568.69,
              "exceptionStatus": false
            }
        }';

        $raw_post_data = file_get_contents('php://input');
        $ipn = json_decode($raw_post_data);

        $log = "Referrer:\n".$this->request->server('HTTP_REFERER', '')
            ."\n\nIP:\n ".$this->request->getClientIp()
            ."\n\nPOST:\n".$raw_post_data;

        Log::write('log_incoming_request', $log);

        // security: check if invoice exists so we now this is an authentic bitpay IPN callback
        try {
            $client = $this->getBitPayClient();
            $client->getInvoice($ipn->id);
        } catch (\Exception $e) {
            Log::write('bitpay error: cannot find invoice '.$ipn->id, 'check if this is authentic IPN callback sent by bitpay', true, Log::TYPE_CRITICAL);
            return false;
        }

        $this->ins_id = $ipn->id;
        $this->ins_url = $ipn->url;
        $this->ins_posData = $ipn->posData;
        $this->ins_status = $ipn->status;
        $this->ins_btcPrice = $ipn->btcPrice;
        $this->ins_price = $ipn->price;
        $this->ins_currency = $ipn->currency;
        $this->ins_invoiceTime = $ipn->invoiceTime;
        $this->ins_expirationTime = $ipn->expirationTime;
        $this->ins_currentTime = $ipn->currentTime;
        $this->ins_btcPaid = $ipn->btcPaid;
        $this->ins_rate = $ipn->rate;
        $this->ins_exceptionStatus = $ipn->exceptionStatus;
        $this->ins_bitpay = isset($ipn->bitpay) ? $ipn->bitpay : null;
        $this->ins_all = $raw_post_data;

        return true;
    }

    private function buildOrder($order_id)
    {
        $OrderModel = new OrderModel();
        $order = $OrderModel->getOrder($order_id);

        if(!$order) {
            Log::write('log_cannot_update_transaction', $order_id, true, Log::TYPE_CRITICAL);
            return false;
        }

        $this->order_invoice_id = $order->invoice_id;
        $this->order_product_id = $order->product_id;
        $this->order_customer_name = $order->customer_name;
        $this->order_customer_email = $order->customer_email;
        $this->order_total = $order->total;
        $this->order_currency = $order->currency;
        $this->order_created_at = $order->created_at;

        return true;
    }


}

class Order {

    public $invoice_id;
    public $product_id;
    public $customer_name;
    public $customer_email;
    public $total;
    public $currency;
    public $created_at;

}

class OrderModel {

    public $row;

    public function getOrder($invoice_id)
    {

        $this->row = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'order_'.$invoice_id)->first();

        if(!$this->row || !$this->row->value) {
            return false;
        }

        $order_decoded = json_decode($this->row->value);

        // unpack
        $order = new Order();
        $order->invoice_id = $order_decoded->invoice_id;
        $order->product_id = $order_decoded->product_id;
        $order->customer_name= $order_decoded->customer_name;
        $order->customer_email = $order_decoded->customer_email;
        $order->total = $order_decoded->total;
        $order->currency = $order_decoded->currency;
        $order->created_at = $order_decoded->created_at;

        return $order;
    }

    public function createOrder($invoice_id, $product_id, $total, $currency, $customer_name, $customer_email)
    {
        $order = new Order();

        $order->invoice_id = $invoice_id;
        $order->product_id = $product_id;
        $order->customer_name= $customer_name;
        $order->customer_email = $customer_email;
        $order->total = $total;
        $order->currency = $currency;
        $order->created_at = Carbon::create()->toDateTimeString();

        $this->row = new Plugin();
        $this->row->plugin_name = Setup::$plugin_name;
        $this->row->key = 'order_'.$invoice_id;
        $this->row->value = json_encode($order);
        $this->row->save();

        return $order;

    }

    public function saveOrder(Order $order)
    {
        $this->row->value = json_encode($order);
        $this->row->save();
    }

}

class Setup {

    public static $plugin_name = 'bitpay';
    public static $minimum_version = '1.5';

}

class Options {

    public static function getAll()
    {
        return Plugin::getData(Setup::$plugin_name);
    }

    public static function get($value, $default = null)
    {
        $options = Plugin::getData(Setup::$plugin_name);

        return ($options->where('key', $value)->first() && $options->where('key', $value)->first()->value) ? $options->where('key', $value)->first()->value : $default;
    }

    public static function update($key, $value)
    {
        return Plugin::updateValue(Setup::$plugin_name, $key, $value);
    }
}

Event::listen('App\Events\PluginMenu', function($event)
{
    return '<li class="'.(getRouteName() == 'bitpay@setup' ? 'active' : '').'"><a href="'.url('/bitpay').'"><i class="fa fa-credit-card"></i><span>BitPay</span></a></li>';
});


Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::get('bitpay', '\App\Plugins\BitPay\BitPayController@setup');
        Route::post('bitpay', '\App\Plugins\BitPay\BitPayController@update');
    });

    Route::get('purchase_bitpay/{product_id}', '\App\Plugins\BitPay\BitPayController@placeOrder');
    Route::post('purchase_bitpay/{product_id}', '\App\Plugins\BitPay\BitPayController@placeOrderSubmit');
    Route::post('bitpayipn', '\App\Plugins\BitPay\BitPayController@callback');

});


Event::listen('App\Events\ContentProductsEdit', function($event)
{
    $product = Product::findOrFail($event->product_id);

    if(APP_VERSION < Setup::$minimum_version  || !Options::get('pairing_code') || !$product->getPrice()) {
        return;
    }

    $purchase_link = url('purchase_bitpay/'.$event->product_id);
    $image_link = url('/inc/app/Plugins/'.basename(__DIR__).'/img/button-large.png');

    $form_button = '<form target="bitpay" action="'.$purchase_link.'" method="get">
    <input type="image" src="'.$image_link.'" border="0" name="submit">
</form>';

    $bootstrap_button = '<a href="'.$purchase_link.'" class="btn btn-primary">Buy Now</a>';

    return '
    <div class="box box-success">
        <div class="box-header">
            <h3 class="box-title">BitPay Integration</h3>
        </div>
        <div class="box-body">
            <p>
              <button data-target="#bitpayModal" data-toggle="modal" class="btn btn-secondary pull-right" type="button">Buy Button Code</button>
            </p>
        </div>
    </div>
    
    <!-- Modal -->
    <div class="modal fade" id="bitpayModal" tabindex="-1" role="dialog" aria-labelledby="bitpayModalLabel">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="bitpayModalLabel">BitPay Buy Button Code</h4>
          </div>
          <div class="modal-body">
          
          <div class="nav-tabs-custom no-shadow">
						<ul class="nav nav-tabs">
							<li class="active"><a href="#bitpaybutton_1" data-toggle="tab">Classic Form Button</a></li>
							<li><a href="#bitpaybutton_2" data-toggle="tab">Bootstrap Button</a></li>
							<li><a href="#bitpaybutton_3" data-toggle="tab">Email</a></li>
						</ul>
						<br>
						<div class="tab-content">
							<div class="tab-pane active" id="bitpaybutton_1">
                                <h4>HTML Code:</h4>
                                <pre>'.htmlentities($form_button).'</pre>
                                <hr>
                                <h4>Preview:</h4>
                                <br>
                                <div>'.$form_button.'</div>
                            </div>
                            <div class="tab-pane" id="bitpaybutton_2">
								<h4>Bootstrap HTML Code:</h4>
                                <pre>'.htmlentities($bootstrap_button).'</pre>
                                <hr>
                                <h4>Preview:</h4>
                                <br>
                                <div>'.$bootstrap_button.'</div>
							</div>
							<div class="tab-pane" id="bitpaybutton_3">
								<div class="form-group">
									<h4>Email Link:</h4>
                                <pre>'.$purchase_link.'</pre>
								</div>
							</div>
						</div>
  		  </div>

		  </div>		
          <div class="modal-footer">

          </div>
        </div>
      </div>
    </div>
    ';
});