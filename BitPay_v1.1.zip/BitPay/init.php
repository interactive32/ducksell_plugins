<?php
$name = 'BitPay integration';
$version = '1.1';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
