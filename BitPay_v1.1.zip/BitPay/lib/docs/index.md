##  BitPay PHP Library Documentation
This is end user documentation for the BitPay PHP library. This document
SHOULD answer all questions a developer has and helps new developers
gain a deeper understanding of the PHP Client Library.

Contents:

Documentation Conventions
=========================

> **note**
>
> Notes are used to provide some extra information.

> **warning**
>
> Warnings are used when things might get a little tricky or when a lot
> of people are having issues.
