##  Changelog
Documents the changes that have been made during the development of this
project.

2.x
===

Uses the new API

2.3.0
-----

-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)

2.2.0
-----

-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)

2.1.0
-----

-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)

1.x
===

Deprecated and uses old API

1.0.0
-----

-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
-   [PR \#X](https://github.com/ionux/new-api-php-client/pull/1)
