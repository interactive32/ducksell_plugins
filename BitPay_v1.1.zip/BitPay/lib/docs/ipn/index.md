##  'Instant Payment Notifications (IPN)'
If enabled, IPNs are sent from BitPay servers to your requested
Notification URL using a POST request with a JSON body containing
information about the invoice.
