##  Documentation
Documentation is built using [Read the Docs](https://readthedocs.org/)
and can be built using [Sphinx](http://sphinx-doc.org/)

To build the docs, make sure you install Sphinx. Change directories to
`docs` run the command `make html` and just open up the files that are
generated in the `docs/_build/html` directory.

For more information on installing Sphinx, see
<http://sphinx-doc.org/latest/install.html>
