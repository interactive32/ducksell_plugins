@include('partials.head_minimal')
<body>
{!! $plugins_body_top !!}
<div class="wrapper">
    <section class="content" style="margin-top: 20px">
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-2">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">{!! $item !!}</h3>
                        <div class="pull-right">
                            {!! $price !!}
                        </div>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                {!! Form::open() !!}
                                @include('partials.form_errors')
                                <div class="form-group">
                                    {!! Form::label('name', 'Your Name') !!}
                                    {!! Form::text('name', '', ['class' => 'form-control']) !!}
                                </div>
                                <div class="form-group">
                                    {!! Form::label('email', 'Your Email*') !!}
                                    {!! Form::text('email', '', ['class' => 'form-control']) !!}
                                    <small>* Download link will be sent here after your transaction has been confirmed.</small>
                                </div>
                            </div>
                            <div class="box-footer">
                                {!! Form::submit('Proceed to checkout', array('class' => 'btn btn-primary pull-right')) !!}
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@include('partials.js_minimal')
{!! $plugins_body_bottom !!}
</body>
</html>