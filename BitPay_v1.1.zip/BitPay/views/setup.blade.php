@extends('app')

@section('content')

<section>
    <div class="row">
        <div class="col-lg-4">
            <div class="box box-success">
                <div class="box-header">
                    <h3 class="box-title">Instructions</h3>
                </div>
                <div class="box-body">
                    <div class="box no-shadow no-border">
                        @if(strpos(url(), 'https://') === false)
                            <p>
                                <strong>WARNING: You are not using HTTPS. BitPay IPN may not work properly unless your server supports SSL. Click <a href="https://{{ \App\Services\Util::stripProtocol(url()) }}/bitpay">here</a> to switch to HTTPS.</strong>
                            </p>
                        @endif
                        <p>
                            1. Open your account at <a href="https://bitpay.com">https://bitpay.com</a> and complete three steps to become eligible for accepting bitcoins.
                        </p>
                        <p>
                            2. On bitpay go to 'Payment Tools' and click on 'Point of Sale App'
                        </p>
                        <p>
                            3. Click on 'Add New Pairing Code' button to generate your new pairing code.
                        </p>
                        <p>
                            4. Copy & Paste this code to 'Token Pairing Code' field in plugin setup.
                        </p>
                        <p>
                            5. Click 'Submit' to save the settings.
                        </p>
                        <p>
                            6. Go to product page where you should now see your 'Buy Button Code'.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8">
            <div class="box box-success box-solid">
                <div class="box-header">
                    <h3 class="box-title">Setup</h3>
                </div>
                <div class="box-body">
                    <div class="box no-shadow no-border">
                        <div class="box-body">
                            {!! Form::open() !!}
                            @include('partials.form_errors')
                            <div class="form-group">
                                {!! Form::label('mode', 'Mode') !!}
                                {!! Form::select('mode', ['test' => 'Test (test.bitpay.com)', 'live' => 'Live'], $options->where('key', 'mode')->first() ? $options->where('key', 'mode')->first()->value : 'test', ['class' => 'form-control']) !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('currency', 'Currency') !!}
                                {!! Form::select('currency', ['USD' => 'USD'], $options->where('key', 'currency')->first() ? $options->where('key', 'currency')->first()->value : 'USD', ['class' => 'form-control']) !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('pairing_code', 'Token Pairing Code') !!}
                                {!! Form::text('pairing_code', $options->where('key', 'pairing_code')->first() ? $options->where('key', 'pairing_code')->first()->value : '', ['class' => 'form-control']) !!}
                                <small>Note: if you switch from test to live you will have to generate and update new token pairing code.</small>
                            </div>
                        </div>
                        <div class="box-footer">
                            {!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


@endsection
