<?php namespace App\Plugins\CustomerFiles;


use App\Events\DownloadFile;
use App\Events\FileSave;
use App\Http\Controllers\Controller;
use App\Models\Download;
use App\Models\File;
use App\Models\Log;
use App\Models\Plugin;
use App\Models\User;
use App\Services\TemplateService;
use App\Services\Util;
use Auth;
use Event;
use Input;
use Redirect;
use Request;
use Response;
use Route;
use Symfony\Component\Translation\Translator;
use Symfony\Component\Translation\Loader\ArrayLoader;
use URL;
use Validator;

class CustomerFilesController extends Controller {

    public $default_mail_template = "Hi,\n\nYour file is ready to download.\n\nDownload link: {{ \$download_link }}\n\nRegards,\nThe Team\n";
    public $default_mail_subject = "Your file is ready to download";

    public function setup()
    {
        if(APP_VERSION < Setup::$minimum_version) {
            return view(basename(__DIR__) . '/views/requirements');
        };

        return view(basename(__DIR__).'/views/setup')->with([
            'template' => Options::getOption('mail_template', $this->default_mail_template),
            'mail_subject' => Options::getOption('mail_subject', $this->default_mail_subject),
            'default_file_description' => Options::getOption('default_file_description', ''),
            'data' => Options::getCustomerFiles(null, Setup::$base_url),
        ]);
    }

    public function update()
    {
        $rules = [
            'mail_template' => 'required',
            'mail_subject' => 'required',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to(Setup::$base_url)
                ->withErrors($validator)
                ->withInput();
        } else {

            $TemplateService = new TemplateService();
            $TemplateService->setContent(Input::get('mail_template'));
            $TemplateService->setVars(['download_link' => 'http://example.com']);

            if($TemplateService->render() === false) {
                return Redirect::to(Setup::$base_url)
                    ->withErrors(trans('app.template_error'))
                    ->withInput();
            }

            try {
                Plugin::updateValue(Setup::$plugin_name.'_options', 'mail_template', Input::get('mail_template'));
                Plugin::updateValue(Setup::$plugin_name.'_options', 'mail_subject', Input::get('mail_subject'));
                Plugin::updateValue(Setup::$plugin_name.'_options', 'default_file_description', Input::get('default_file_description', ''));
            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to(Setup::$base_url)
                    ->withErrors($e->getMessage())
                    ->withInput();
            }

            flash()->success(trans('app.success'));
            return Redirect::to(Setup::$base_url);

        }
    }

    public function addFile($customer_id)
    {
        $customer = User::customers()->findOrFail($customer_id);

        $existing_files = glob(config('global.file_tmp') . '*');
        foreach ($existing_files as &$file) {
            $file = str_replace(config('global.file_tmp'), '', $file);
        }
        $existing_files = array_combine($existing_files, $existing_files);

        return view(basename(__DIR__).'/views/add')->with([
            'page_title' => trans('app.files') . ' | ' . trans('app.add_new'),
            'back_button' => ['route' => '/customers/'.$customer_id.'/edit', 'title' => $customer->name],
            'existing_files' => $existing_files,
            'tmp_path' => config('global.file_tmp'),
            'template' => Options::getOption('mail_template', $this->default_mail_template),
            'default_file_description' => Options::getOption('default_file_description', ''),
        ]);
    }

    public function storeFile($customer_id)
    {
        $customer = User::customers()->findOrFail($customer_id);

        if(!$customer->transactions()->first()) {
            return Redirect::to(Setup::$base_url)
                ->withErrors("No sales - cannot add files")
                ->withInput();
        }

        $file_name_internal = $file_name = false;

        if (Input::hasFile('file')) {
            $file_name = Input::file('file')->getClientOriginalName();
            $file_name_internal = Util::uploadFileFromInput(Input::file('file'));

        } elseif (Input::get('existing_file')) {
            $file_name = Input::get('existing_file');
            $file_name_internal = Util::getFileFromServer($file_name);
        }

        // error
        if(!$file_name_internal || !$file_name) {
            return Redirect::to('add_file_to_customer/'.$customer_id)
                ->withErrors(trans('app.select_file'))
                ->withInput();
        }

        $File = new File();

        try {
            $file = $File->addFile($file_name, $file_name_internal, Input::get('description', ''));

            Options::addFileToPluginDB($customer->id, $file->id);

            Event::fire(new FileSave($file));
            flash()->success(trans('app.success'));
            return Redirect::to('/customers/'.$customer_id.'/edit');
        } catch (\Exception $e) {
            Log::writeException($e);
            return Redirect::to('/customers/'.$customer_id.'/edit')
                ->withErrors($e->getMessage())
                ->withInput();
        }
    }

    public function destroyFile($plugin_id)
    {
        $file = Options::getCustomerFile($plugin_id);

        Options::removeFileFromPluginDB($plugin_id);

        // detach all products
        foreach ($file->products as $product) {
            $product->files()->detach($file->id);
        }

        try {
            // remove db record
            $file->delete();
            // remove file on disk
            unlink(config('global.file_path') . $file->file_name_internal);
            flash()->success(trans('app.success'));
        } catch (\Exception $e) {
            Log::writeException($e);
            flash()->error(trans('app.error').' '.$e->getMessage());
        }

        return Redirect::to(URL::previous());
    }

    public function downloadFile($plugin_id)
    {
        $file = Options::getCustomerFile($plugin_id, Auth::user()->id);

        Event::fire(new DownloadFile(0, $file));

        // log downloads
        $download = new Download();
        $download->user_id = Auth::user()->id;
        $download->file_name = $file->file_name;
        $download->ip_address = Request::getClientIp();
        $download->save();

        return Response::download(config('global.file_path') . $file->file_name_internal, $file->file_name);
    }

    public function sendEmail($customer_id)
    {
        $rules = [
            'mail_template' => 'required',
            'mail_subject' => 'required',
            'to' => 'required|email',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to(URL::previous())
                ->withErrors($validator)
                ->withInput();
        }

        $customer = User::customers()->findOrFail($customer_id);

        if(!$customer->transactions()->first()) {
            return Redirect::to(URL::previous())
                ->withErrors("No sales - cannot add files")
                ->withInput();
        }

        $direct_link = url('/download') .'?q='. $customer->transactions()->first()->hash;
        $TemplateService = new TemplateService();
        $TemplateService->setContent(Input::get('mail_template'));
        $TemplateService->setVars(['download_link' => $direct_link]);

        Util::sendMail(
            Input::get('to'),
            Options::getOption('mail_subject', Input::get('mail_subject')),
            Options::getOption('mail_body', $TemplateService->render())
        );

        return Redirect::to(URL::previous());
    }

}

class Setup {

    public static $plugin_name = 'customer_files';
    public static $minimum_version = '1.5';
    public static $base_url = 'customer_files';

}

class Options {

    public static function getOption($value, $default = null)
    {
        $options = Plugin::getData(Setup::$plugin_name.'_options');

        return ($options->where('key', $value)->first() && $options->where('key', $value)->first()->value) ? $options->where('key', $value)->first()->value : $default;
    }

    public static function addFileToPluginDB($customer_id, $file_id)
    {
        $Plugin = new Plugin();

        $data = [
            'plugin_name' => Setup::$plugin_name,
            'key' => $customer_id,
            'value' => $file_id,
        ];

        return $Plugin->insert($data);
    }

    public static function removeFileFromPluginDB($plugin_id)
    {

        $Plugin = new Plugin();

        return $Plugin
            ->where('plugin_name', Setup::$plugin_name)
            ->where('id', $plugin_id)
            ->delete();
    }

    public static function getCustomerFiles($customer_id = null, $paginate_path = false)
    {
        $Plugin = new Plugin();

        $builder = $Plugin
            ->selectRaw('
            plugins.id plugin_id,
            plugins.key plugin_customer_id,
            plugins.value plugin_file_id,
            files.id file_id, 
            files.file_name file_name, 
            files.description file_description, 
            users.id user_id, 
            users.name user_name')
            ->join('files', 'files.id', '=', 'plugins.value')
            ->join('users', 'users.id', '=', 'plugins.key')
            ->where('plugins.plugin_name', Setup::$plugin_name);

        if($customer_id) {
            $builder->where('plugins.key', $customer_id);
        }

        if($paginate_path) {
            $ret = $builder->paginate(session('per_page'));
            $ret->setPath($paginate_path);
            return $ret;
        }
        return $builder->get();
    }


    public static function getCustomerFile($plugin_id, $customer_id = null)
    {
        $Plugin = new Plugin();
        $builder = $Plugin
            ->where('plugin_name', Setup::$plugin_name)
            ->where('id', $plugin_id);

        if($customer_id) {
            $builder->where('plugins.key', $customer_id);
        }

        $file = $builder->firstOrFail();

        return File::findOrFail($file->value);
    }

}

Event::listen('App\Events\PluginMenu', function($event)
{
    return '<li class="'.(getRouteName() == Setup::$base_url.'@setup' ? 'active' : '').'"><a href="'.url(Setup::$base_url).'"><i class="fa fa-file-zip-o"></i><span>Customer Files</span></a></li>';
});


Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::get(Setup::$base_url, '\App\Plugins\CustomerFiles\CustomerFilesController@setup');
        Route::post(Setup::$base_url, '\App\Plugins\CustomerFiles\CustomerFilesController@update');
        Route::get('add_file_to_customer/{customer_id}', '\App\Plugins\CustomerFiles\CustomerFilesController@addFile');
        Route::post('add_file_to_customer/{customer_id}', '\App\Plugins\CustomerFiles\CustomerFilesController@storeFile');
        Route::post('remove_file_from_customer/{plugin_id}', '\App\Plugins\CustomerFiles\CustomerFilesController@destroyFile');
        Route::post('send_email_to_customer/{customer_id}', '\App\Plugins\CustomerFiles\CustomerFilesController@sendEmail');
    });

    Route::group(['middleware' => ['customer', 'csrf']], function()
    {
        Route::get('download_customer_file/{plugin_id}', '\App\Plugins\CustomerFiles\CustomerFilesController@downloadFile');
    });

});

Event::listen('App\Events\CustomerDownloads', function($event)
{
    $customer = Auth::user();

    $files = Options::getCustomerFiles($customer->id);

    // no customer files? return regular download page
    if(!$files->first()) {
        return false;
    }

    return view(basename(__DIR__).'/views/download')->with([
        'page_title' => trans('app.download'),
        'customer' => Auth::user(),
        'transactions' => $event->transactions,
        'customer_files' => $files,
    ]);

});


Event::listen('App\Events\ContentCustomersEdit', function($event)
{
    if(APP_VERSION < Setup::$minimum_version) {
        return;
    }
    $customer = User::customers()->findOrFail($event->customer_id);

    $files = Options::getCustomerFiles($customer->id);

    $Controller = new CustomerFilesController();

    return view(basename(__DIR__).'/views/content_customers_edit')->with([
        'files' => $files,
        'customer' => $customer,
        'template' => Options::getOption('mail_template', $Controller->default_mail_template),
        'mail_subject' => Options::getOption('mail_subject', $Controller->default_mail_subject),
    ]);

});