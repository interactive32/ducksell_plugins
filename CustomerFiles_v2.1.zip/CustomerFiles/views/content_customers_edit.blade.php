<div class="box box-success">
	<div class="box-header">
		<h3 class="box-title">Customer Files</h3>
		<div class="pull-right box-tools">
			<button data-widget="collapse" type="button" class="btn btn-default btn-sm">
				<i class="fa fa-minus"></i>
			</button>
		</div>
	</div>
	<div class="box-body">
		<p>
			@foreach($files as $file)
			<div class="clearfix">
				<a target="_blank" href="{{ url('files/'.$file->file_id.'/edit') }}">{{ $file->file_name }}</a>
				<a data-confirm="Are you sure?" data-method="post" class="btn btn-xs pull-right" href="{{ url('remove_file_from_customer/'.$file->plugin_id) }}">
					<i class="fa fa-remove"></i> Delete
				</a>
				<a class="btn btn-xs pull-right" href="{{ url('products/download/'.$file->file_id) }}">
					<i class="fa fa-download"></i> Download
				</a>
			</div>
			@endforeach
		</p>
	</div>
	<div class="box-footer">
		<p class="pull-right">
			@if($customer->transactions()->first())
				<button data-target="#customerFilesModal" data-toggle="modal" class="btn btn-secondary" type="button">Send email</button> &nbsp;
				<a href="{{ url('add_file_to_customer/'.$customer->id) }}" class="btn btn-primary" type="button">Add File</a>
			@else
				No sales - cannot add files
			@endif
		</p>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="customerFilesModal" tabindex="-1" role="dialog" aria-labelledby="customerFilesModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="customerFilesModalLabel">Send Email</h4>
			</div>
			<div class="box-body">
				{!! Form::open(['url' => url('send_email_to_customer/'.$customer->id)]) !!}
				@include('partials.form_errors')
				<div class="form-group">
					{!! Form::label('to', 'To') !!}
					{!! Form::text('to', $customer->email, ['class' => 'form-control']) !!}
				</div>
				<div class="form-group">
					{!! Form::label('mail_subject', 'Subject') !!}
					{!! Form::text('mail_subject', $mail_subject, ['class' => 'form-control']) !!}
				</div>
				<div class="form-group">
					{!! Form::label('mail_template', 'Message') !!}
					{!! Form::textarea('mail_template', $template, ['class' => 'form-control']) !!}
				</div>
			</div>
			<div class="box-footer">
				{!! Form::submit('Send email', array('class' => 'btn btn-primary pull-right')) !!}
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>