@extends('app')

@section('content')

<section>
    <div class="row">
        <div class="col-lg-8">
            <div class="box box-success box-solid">
                <div class="box-header">
                    <h3 class="box-title">Customer Files Setup</h3>
                </div>
                <div class="box-body">
                    <div class="box no-shadow no-border">
                        <div class="box-body">
                            {!! Form::open() !!}
                            @include('partials.form_errors')
                            <div class="form-group">
                                {!! Form::label('mail_subject', 'Default email subject') !!}
                                {!! Form::text('mail_subject', $mail_subject, ['class' => 'form-control']) !!}
                            </div>
                            <div class="form-group">
                                {!! Form::label('mail_template', 'Default email template') !!}
                                {!! Form::textarea('mail_template', $template, ['class' => 'form-control']) !!}
                            </div>
                            <hr>
                            <div class="form-group">
                                {!! Form::label('default_file_description', 'Default file description') !!}
                                {!! Form::textarea('default_file_description', $default_file_description, ['class' => 'form-control']) !!}
                            </div>
                        </div>
                        <div class="box-footer">
                            {!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="box box-success box-solid">
                <div class="box-header">
                    <h3 class="box-title">All Customer Files</h3>
                    <div class="pull-right box-tools">
                        <button data-widget="collapse" type="button" class="btn btn-default btn-sm">
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                    <p>
                    @foreach($data as $file)
                        <div class="clearfix">
                            <a target="_blank" href="{{ url('files/'.$file->file_id.'/edit') }}">{{ $file->file_name }}</a>
                            (<a target="_blank" href="{{ url('customers/'.$file->user_id.'/edit') }}">{{ $file->user_name }}</a>)

                            <a data-confirm="Are you sure?" data-method="post" class="btn btn-xs pull-right" href="{{ url('remove_file_from_customer/'.$file->plugin_id) }}">
                                <i class="fa fa-remove"></i> {{ trans('app.delete') }}
                            </a>
                        </div>
                        @endforeach
                     </p>
                        @include('partials.pagination', [$data])
                </div>
                <div class="box-footer">
                    <p>
                        Note: To add a file please go to customer's page
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
