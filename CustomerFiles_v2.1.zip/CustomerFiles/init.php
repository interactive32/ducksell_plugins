<?php
$name = 'Customer Files';
$version = '2.1';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
