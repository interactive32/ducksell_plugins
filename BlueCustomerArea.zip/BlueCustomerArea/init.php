<?php
$name = 'Blue customer area - alternative download area layout';
$version = '1.0';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
