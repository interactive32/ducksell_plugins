<?php namespace App\Plugins\BlueCustomerArea;

use Auth;
use Event;


Event::listen('App\Events\CustomerDownloads', function($event)
{

    return view(basename(__DIR__).'/views/download')->with([
        'page_title' => trans('app.download'),
        'customer' => Auth::user(),
        'transactions' => $event->transactions,
    ]);

});

