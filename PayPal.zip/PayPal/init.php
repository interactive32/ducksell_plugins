<?php
$name = 'Paypal integration';
$version = '2.7';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
