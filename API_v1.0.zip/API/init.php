<?php
$name = 'API Plugin';
$version = '1.0';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
