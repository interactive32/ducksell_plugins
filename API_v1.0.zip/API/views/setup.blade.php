@extends('app')

@section('content')

    <section>
        <div class="row">
            <div class="col-lg-3">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Latest Requests</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                @foreach($logs as $log)
                                    <div>
                                        {{ json_decode($log->value)->date }} {{ json_decode($log->value)->client_ip }}<br>
                                        Request:<br>{{ json_decode($log->value)->route }}<br>
                                        Response:<br>{{ json_decode($log->value)->response }}<br>
                                    </div>
                                    <hr>
                                @endforeach
                                @if($logs->first())
                                <div class="text-right">
                                    <a class="btn btn-primary" href="{{ url('/exportapilog') }}">
                                        <i class="fa fa-file-excel-o"></i>
                                        {{ trans('app.export') }}
                                    </a>
                                    <a class="btn btn-warning" href="{{ url('/purgeapilog') }}" data-method="post" data-confirm="{{ trans('app.are_you_sure') }}">
                                        <i class="fa fa-trash-o"></i>
                                        {{ trans('app.purge') }}
                                    </a>
                                </div>
                                @else
                                    No requests found in log
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">API Methods</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                <div class="method">
                                    <h4><strong>Verify License (GET Method)</strong></h4>

                                    Request:
                                    <pre>{{ url('api/{api_key}/verify_license/{license_number}') }}</pre>

                                    Sample JSON Response:

                                    <pre>{
    "customer_name":"John Doe",
    "transaction_date":"2016-04-15 09:33:10",
    "transaction_status":"Approved",
    "product_name":"Sample Product",
    "product_id":"7"
}</pre>
                                </div>
                                <hr>
                                <div class="method">
                                    <h4><strong>Get Customer Details (GET Method)</strong></h4>

                                    Request:
                                    <pre>{{ url('api/{api_key}/get_customer_details/{email}') }}</pre>

                                    Sample JSON Response:

                                    <pre>{
    "id":"101",
    "name":"John Doe",
    "email":"john@example.com",
    "description":"John Doe, 55 Lane Ave. NV, USA",
    "created_at":"2016-04-15 09:33:10",
}</pre>
                                </div>
                                <hr>
                                <div class="method">
                                    <h4><strong>Get Product Details (GET Method)</strong></h4>

                                    Request:
                                    <pre>{{ url('api/{api_key}/get_product_details/{id}') }}</pre>

                                    Sample JSON Response:

                                    <pre>{
    "id":"5",
    "name":"Sample Product",
    "description":"My Sample Digital Product",
    "created_at":"2016-04-15 09:33:10",
    "files":[
        {
            "id":"33",
            "name":"sample.zip",
            "size":"190022",
            "description":"Sample file"
        },
        {
            "id":"31",
            "name":"images.zip",
            "size":"5308567",
            "description":"My Images"
        }
    ]
}</pre>
                                </div>
                                <hr>
                                <div class="method">
                                    <h4><strong>Get Transaction Details (GET Method)</strong></h4>

                                    Request:
                                    <pre>{{ url('api/{api_key}/get_transaction_details/{id}') }}</pre>

                                    Sample JSON Response:

                                        <pre>{
    "id":"5",
    "status":"Approved",
    "status_id":"2",
    "external_sale_id":"5555555",
    "payment_processor":"paypal",
    "currency":"USD",
    "amount":"14.16",
    "customer_id":"20",
    "customer_name":"John Doe",
    "customer_email":"john@example.com",
    "customer_details":"John Doe, 55 Lane Ave. NV, USA",
    "created_at":"2016-04-15 09:33:10",
    "products":[
        {
            "id":"5",
            "name":"Sample Product",
            "amount":"10.00"
        },
        {
            "id":"6",
            "name":"Premium Images",
            "amount":"4.16"
        }
    ]
}</pre>
                                </div>
                            </div>
                            <div class="box-footer">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">API Keys</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                @foreach($api_keys as $api_key)
                                    <div>
                                        <h4 class="clearfix">Key:
                                            <div class="pull-right">
                                                <a href="{{ url('removeapikey/'.str_replace('apikey_', '', $api_key->key)) }}" data-method="post" data-confirm="{{ trans('app.are_you_sure') }}">
                                                    <i class="fa fa-remove"></i>
                                                </a>
                                            </div>
                                        </h4>
                                        <pre>{{ str_replace('apikey_', '', $api_key->key) }}</pre>
                                        <h4>Permissions:</h4>
                                        @foreach($available_methods as $method)
                                            <div class="clearfix">
                                                <div class="pull-left">{{ $method }}</div>
                                                <div class="pull-right">
                                                <a href="{{ url('toggleapikeypermisions/'.str_replace('apikey_', '', $api_key->key).'/'.$method) }}" class="btn btn-xs" data-method="post" }}>
                                                    @if(in_array($method, json_decode($api_key->value)))
                                                        <i class="fa fa-toggle-on"></i> {{ trans('app.disable') }}
                                                    @else
                                                        <i class="fa fa-toggle-off"></i> {{ trans('app.enable') }}
                                                    @endif
                                                </a>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                    <hr>
                                @endforeach
                                <a class="btn btn-primary pull-right" href="{{ url('/addapikey') }}">{{ trans('app.add_new') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
