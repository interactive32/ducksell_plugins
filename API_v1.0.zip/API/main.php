<?php namespace App\Plugins\API;

use App\Http\Controllers\Controller;
use App\Models\Plugin;
use App\Models\Product;
use App\Models\ProductTransaction;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Event;
use Redirect;
use Route;

Event::listen('App\Events\PluginMenu', function($event)
{
    return '<li class="'.(getRouteName() == 'api_setup@setup' ? 'active' : '').'"><a href="'.url('/api_setup').'"><i class="fa fa-exchange"></i><span>API</span></a></li>';
});

Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::get(Setup::$base_url, '\App\Plugins\API\APIController@setup');
        Route::post('toggleapikeypermisions/{key}/{permission}', '\App\Plugins\API\APIController@toggleApiPermissions');
        Route::get('addapikey', '\App\Plugins\API\APIController@addApiKey');
        Route::post('removeapikey/{key}', '\App\Plugins\API\APIController@removeApiKey');
        Route::get('exportapilog', '\App\Plugins\API\APIController@exportLog');
        Route::post('purgeapilog', '\App\Plugins\API\APIController@purgeLog');
    });

    Route::get('api/{api_key}/verify_license/{license_number}', '\App\Plugins\API\APIController@method_verifyLicense');
    Route::get('api/{api_key}/get_customer_details/{email}', '\App\Plugins\API\APIController@method_getCustomerDetails');
    Route::get('api/{api_key}/get_product_details/{id}', '\App\Plugins\API\APIController@method_getProductDetails');
    Route::get('api/{api_key}/get_transaction_details/{id}', '\App\Plugins\API\APIController@method_getTransactionDetails');
});


class APIController extends Controller
{

    public $current_request_key;
    public $current_request_permissions;

    public $status_code = 1;
    public $status_message = '';
    public $available_methods = [
        'verify_license',
        'get_customer_details',
        'get_product_details',
        'get_transaction_details',
    ];

    public function __construct()
    {
        $api_key = Route::getCurrentRoute()->getParameter('api_key');

        if($api_key) {
            $this->verifyApiKey($api_key);
        }

        return parent::__construct();
    }

    public function setup()
    {
        $api_keys = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'like', "apikey_%")->get();

        $logs = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'log')->orderBy('id', 'DESC')->limit(5)->get();

        return view(basename(__DIR__).'/views/setup')->with([
            'api_keys' => $api_keys,
            'logs' => $logs,
            'available_methods' => $this->available_methods,
        ]);
    }

    public function toggleApiPermissions($api_key, $permission)
    {
        if(!in_array($permission, $this->available_methods)) {
            return Redirect::to(Setup::$base_url);
        }

        $dbkey = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'apikey_'.$api_key)->firstOrFail();

        $current_permissions = json_decode($dbkey->value);

        if(in_array($permission, $current_permissions)) {
            // revoke permission
            if(($key = array_search($permission, $current_permissions)) !== false) {
                unset($current_permissions[$key]);
            }
        } else {
            // add permission
            $current_permissions[] = $permission;
        }

        // reset array
        $current_permissions = array_values($current_permissions);

        // save back to db
        $dbkey->value = json_encode($current_permissions);
        $dbkey->save();

        return Redirect::to(Setup::$base_url);

    }

    public function exportLog()
    {
        $logs = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'log')->selectRaw('value')->orderBy('id', 'DESC');

        return $this->export($logs);

    }


    public function purgeLog()
    {
        Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'log')->delete();

        return Redirect::to(Setup::$base_url);
    }

    public function addApiKey()
    {
        $key = md5(mt_rand(1000, 9999));
        $permissions = $this->available_methods;

        Plugin::addData(Setup::$plugin_name, ['apikey_'.$key => json_encode($permissions)]);

        return Redirect::to(Setup::$base_url);
    }

    public function removeApiKey($api_key)
    {
        Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'apikey_'.$api_key)->firstOrFail()->delete();

        return Redirect::to(Setup::$base_url);
    }

    private function outputWrapper($data)
    {
        $Request = Route::getCurrentRequest();

        $log =  new \stdClass();
        $log->client_ip = $Request->getClientIp();
        $log->date = Carbon::create()->format(trans('app.date_time_format'));
        $log->route = str_replace(url(), '', $Request->getUri());
        $log->response = json_encode($data);

        Plugin::addData(Setup::$plugin_name, ['log' => json_encode($log)]);

        return json_encode($data);
    }

    private function getStatusResponse()
    {
        $ret = new \stdClass();

        $ret->error = $this->status_code;
        $ret->message = $this->status_message;

        return $ret;
    }

    private function verifyApiKey($key)
    {
        $ret = Plugin::where('plugin_name', Setup::$plugin_name)->where('key', 'apikey_'.$key)->first();

        if(!$ret) {
            $this->status_code = -1;
            $this->status_message = 'API key is not valid';
            echo $this->outputWrapper($this->getStatusResponse());
            die;
        }

        $this->current_request_key = $ret->key;
        $this->current_request_permissions = json_decode($ret->value);

        return true;
    }

    private function checkApiPermissions($method)
    {
        if(!in_array($method, $this->current_request_permissions)) {
            $this->status_code = -2;
            $this->status_message = 'API permission denied';
            echo $this->outputWrapper($this->getStatusResponse());
            die;
        }

        return true;
    }

    public function method_verifyLicense($api_key, $license_number)
    {
        $this->checkApiPermissions('verify_license');
        
        $transaction = ProductTransaction::getTransactionByLicenseNumber($license_number);
        $product = ProductTransaction::getProductByLicenseNumber($license_number);
        $customer = $transaction ? $transaction->customer : false;

        $valid_transactions = [
            Transaction::STATUS_APPROVED,
            Transaction::STATUS_PENDING,
        ];

        if(!$transaction
            || !in_array($transaction->status_id, $valid_transactions)
            || !$product
            || !$customer
            || $customer->trashed()
        ) {
            $this->status_message = 'This license is not valid';
            return $this->outputWrapper($this->getStatusResponse());
        }

        $data = new \stdClass();
        $data->customer_name = $customer->name;
        $data->transaction_date = $transaction->created_at->toDateTimeString();
        $data->transaction_status = trans('app.transaction_status_'.$transaction->status_id);
        $data->customer_name = $customer->name;
        $data->product_name = $product->name;
        $data->product_id = $product->id;

        return $this->outputWrapper($data);
    }

    public function method_getCustomerDetails($api_key, $email)
    {
        $this->checkApiPermissions('get_customer_details');
        
        $customer = User::customers()->where('email', $email)->first();

        if(!$customer || $customer->trashed()) {
            $this->status_message = 'Customer cannot be found';
            return $this->outputWrapper($this->getStatusResponse());
        }

        $data = new \stdClass();
        $data->id = $customer->id;
        $data->name = $customer->name;
        $data->email = $customer->email;
        $data->details = $customer->details;
        $data->created_at = $customer->created_at->toDateTimeString();

        return $this->outputWrapper($data);
    }

    public function method_getProductDetails($api_key, $id)
    {
        $this->checkApiPermissions('get_product_details');
        
        $product = Product::find($id);

        if(!$product || $product->trashed()) {
            $this->status_message = 'Product cannot be found';
            return $this->outputWrapper($this->getStatusResponse());
        }

        $files = [];

        foreach ($product->files as $file) {
            $files[] = [
                'id' => $file->id,
                'name' => $file->file_name,
                'size' => $file->size,
                'description' => $file->description,
            ];
        }

        $data = new \stdClass();
        $data->id = $product->id;
        $data->name = $product->name;
        $data->description = $product->description;
        $data->created_at = $product->created_at->toDateTimeString();
        $data->files = $files;

        return $this->outputWrapper($data);
    }

    public function method_getTransactionDetails($api_key, $id)
    {
        $this->checkApiPermissions('get_transaction_details');
        
        $transaction = Transaction::find($id);

        if(!$transaction) {
            $this->status_message = 'Transaction cannot be found';
            return $this->outputWrapper($this->getStatusResponse());
        }

        $products = [];

        foreach ($transaction->products as $product) {

            $products[] = [
                'id' => $product->id,
                'name' => $product->name,
                'amount' => (string) ($product->pivot->listed_amount / 100),
            ];
        }

        $data = new \stdClass();
        $data->id = $transaction->id;
        $data->status = trans('app.transaction_status_'.$transaction->status_id);
        $data->status_id = $transaction->status_id;
        $data->external_sale_id = $transaction->external_sale_id;
        $data->payment_processor = $transaction->payment_processor;

        $data->currency = $transaction->listed_currency;
        $data->amount = (string) ($transaction->listed_amount / 100);

        $data->customer_id = $transaction->customer->id;
        $data->customer_name = $transaction->customer->name;
        $data->customer_email = $transaction->customer->email;
        $data->customer_details = $transaction->customer->details;

        $data->created_at = $product->created_at->toDateTimeString();

        $data->products = $products;

        return $this->outputWrapper($data);
    }

}

class Setup {

    public static $plugin_name = 'api';
    public static $base_url = 'api_setup';
    public static $minimum_version = '1.0';

}

class Options {

    public static function getAll()
    {
        return Plugin::getData(Setup::$plugin_name);
    }

    public static function get($value, $default = null)
    {
        $options = Plugin::getData(Setup::$plugin_name);

        return ($options->where('key', $value)->first() && $options->where('key', $value)->first()->value) ? $options->where('key', $value)->first()->value : $default;
    }

    public static function update($key, $value)
    {
        return Plugin::updateValue(Setup::$plugin_name, $key, $value);
    }
}