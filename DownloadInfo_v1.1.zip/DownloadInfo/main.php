<?php namespace App\Plugins\DownloadInfo;

use App\Http\Controllers\Controller;
use App\Models\Download;
use Event;
use Route;

Event::listen('App\Events\PluginMenu', function($event)
{
    return '<li class="'.(getRouteName() == 'downloadreport@index' ? 'active' : '').'"><a href="'.url('/downloadreport').'"><i class="fa fa-cloud-download"></i><span>Downloads</span></a></li>';
});

Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::get('downloadreport', '\App\Plugins\DownloadInfo\DownloadReportController@index');
    });

});

class DownloadReportController extends Controller
{

    public function index()
    {
        $builder = Download::search(['ip_address'])
            ->join('users', 'users.id', '=', 'downloads.user_id')
            ->orderBy('downloads.id', 'desc');

        if ($this->isExport()) {
            return $this->export(
                $builder->selectRaw('downloads.created_at time, ip_address, users.name, users.email, file_name')
            );
        }

        $builder ->selectRaw('downloads.created_at time, ip_address, users.email, file_name');
        $downloads = $builder->paginate(session('per_page'));
        $downloads->setPath('downloadreport');

        return view(basename(__DIR__).'/views/downloads')->with([
            'page_title' => trans('app.downloads'),
            'data' => $downloads,
        ]);
    }

}
