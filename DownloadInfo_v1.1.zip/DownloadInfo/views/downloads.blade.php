@extends('app')

@section('content')

<div class="box box-solid">
    <div class="box-header">
        <h3 class="box-title">{{ trans('app.downloads') }}</h3>
        @include('partials.search')
    </div>
    <div class="box-body">
        <div class="row">
            <div class="col-xs-6">
                <div class="action-buttons-top">
                    @include('partials.export')
                </div>
            </div>
            <div class="col-xs-6">
                @include('partials.per_page')
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr role="row">
                                <th>{{ trans('app.time') }}</th>
                                <th>{{ trans('app.ip') }}</th>
                                <th>{{ trans('app.user') }}</th>
                                <th>{{ trans('app.file') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($data as $row)
                            <tr>
                                <td>{{ \Carbon\Carbon::parse($row->time)->format(trans('app.date_time_format')) }}</td>
                                <td>{{ $row->ip_address }}</td>
                                <td>{{ $row->email }}</td>
                                <td>{{ $row->file_name }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        @include('partials.pagination', [$data])
    </div>
</div>

@endsection
