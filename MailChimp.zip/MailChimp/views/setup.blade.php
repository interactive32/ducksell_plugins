@extends('app')

@section('content')

<section>
    <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <div class="box box-success box-solid">
                <div class="box-header">
                    <h3 class="box-title">MailChimp Setup</h3>
                </div>
                <div class="box-body">
                    <div class="box no-shadow no-border">
                        <div class="box-body">
                            {!! Form::open() !!}
                            @include('partials.form_errors')
                            <div class="form-group">
                                {!! Form::label('api_key', 'MailChimp API Key') !!}
                                {!! Form::text('api_key', $options->where('key', 'api_key')->first() ? $options->where('key', 'api_key')->first()->value : '', ['class' => 'form-control']) !!}
                            </div>
                            @if($lists)
                            <div class="form-group" id="email-template">
                                {!! Form::label('list', 'List to add users') !!}
                                {!! Form::select('list', ['0' => 'None'] + $lists, $options->where('key', 'list')->first() ? $options->where('key', 'list')->first()->value : 0, ['class' => 'form-control']) !!}
                            </div>
                            @endif
                        </div>
                        <div class="box-footer">
                            {!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
