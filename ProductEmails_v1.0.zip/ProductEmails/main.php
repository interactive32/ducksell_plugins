<?php namespace App\Plugins\ProductEmails;

use App\Http\Controllers\Controller;
use App\Models\Log;
use App\Models\Plugin;
use App\Models\Transaction;
use App\Services\TemplateService;
use App\Services\Util;
use Event;
use Input;
use Redirect;
use Route;
use URL;
use Validator;


class ProductEmailController extends Controller
{

    public function update($product_id)
    {
        $rules = [
            'mail_template' => 'required',
            'mail_subject' => 'required',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to(URL::previous())
                ->withErrors($validator)
                ->withInput();
        } else {

            $TemplateService = new TemplateService();
            $TemplateService->setContent(Input::get('mail_template'));
            $TemplateService->setVars([
                'direct_link' => 'http://example.com',
                'user_email' => 'test@example.com',
                'user_password' => '123456',
            ]);

            if ($TemplateService->render() === false) {
                return Redirect::to(URL::previous())
                    ->withErrors(trans('app.template_error'))
                    ->withInput();
            }

            try {
                Options::update($product_id.'_subject', Input::get('mail_subject'));
                Options::update($product_id.'_template', Input::get('mail_template'));
                Options::update($product_id.'_bcc', Input::get('bcc_to_admin', 0));
            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to(URL::previous())
                    ->withErrors($e->getMessage())
                    ->withInput();
            }

            flash()->success(trans('app.success'));
            return Redirect::to(URL::previous());

        }
    }

    public function remove($product_id)
    {
        Options::delete($product_id);

        return Redirect::to(URL::previous());
    }
}


class Setup {

    public static $plugin_name = 'product_emails';
    public static $minimum_version = '1.9';

}

class Options {

    public static function get($value, $default = null)
    {
        $options = Plugin::getData(Setup::$plugin_name);

        return ($options->where('key', $value)->first() && $options->where('key', $value)->first()->value) ? $options->where('key', $value)->first()->value : $default;
    }

    public static function update($key, $value)
    {
        return Plugin::updateValue(Setup::$plugin_name, $key, $value);
    }

    public static function delete($product_id)
    {
        $Plugin = new Plugin();

        return $Plugin
            ->where('plugin_name', Setup::$plugin_name)
            ->where('key', 'like', $product_id.'_%')
            ->delete();
    }

    public static function hasTemplateSet($product_id)
    {
        return self::get($product_id.'_subject', false) ? true : false;
    }
}

Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::post('save_custom_purchase_email/{product_id}', '\App\Plugins\ProductEmails\ProductEmailController@update');
        Route::post('remove_custom_purchase_email/{product_id}', '\App\Plugins\ProductEmails\ProductEmailController@remove');
    });

});

Event::listen('App\Events\ContentProductsEdit', function($event)
{
    if(APP_VERSION < Setup::$minimum_version) {
        return;
    }

    $product_id = $event->product_id;

    $subject = Options::get($product_id.'_subject', trans('app.purchase_information'));
    $template = Options::get($product_id.'_template', config('mail.template.thankyou'));
    $bcc = Options::get($product_id.'_bcc', 0);

    return view(basename(__DIR__).'/views/content_product_edit')->with([
        'has_template_set' => Options::hasTemplateSet($product_id),
        'subject' => $subject,
        'template' => $template,
        'product_id' => $product_id,
        'bcc' => $bcc,
    ]);
});

Event::listen('App\Events\EmailPurchase', function($event)
{
    if(APP_VERSION < Setup::$minimum_version) {
        return false;
    }

    $hash = $event->hash;
    $Transaction = new Transaction();

    $transaction = $Transaction->where('hash', $hash)->firstOrFail();
    $products = $transaction->products;
    $customer = $transaction->customer;

    if(!$customer) {
        return false;
    }

    $direct_link = url('/download') .'?q='. $hash;
    $password = trans('app.use_your_old_password');

    // do not update password if already set
    if(!$customer->password) {
        $password = Util::generatePassword();
        $customer->password = bcrypt($password);
        $customer->save();
    }

    foreach($products as $product) {

        $TemplateService = new TemplateService();
        $subject = trans('app.purchase_information');
        $bcc = false;

        if(Options::hasTemplateSet($product->id)) {
            $TemplateService->setContent(Options::get($product->id.'_template'));
            $subject = Options::get($product->id.'_subject');
            $bcc = Options::get($product->id.'_bcc', 0) ? config('global.admin-mail') : false;
        } else {
            $TemplateService->loadSystemTemplate('thankyou');
        }

        $TemplateService->setVars([
            'direct_link' => $direct_link,
            'user_email' => $customer->email,
            'user_password' => $password,
        ]);

        $ret = Util::sendMail($customer->email, $subject, $TemplateService->render(), false, $bcc);

        if(!$ret) {
            Log::write('log_cannot_send_email', $customer->email, true, Log::TYPE_CRITICAL);
        }
    }

    return true;
});