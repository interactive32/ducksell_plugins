<div class="box box-success">
	<div class="box-header">
		<h3 class="box-title">Custom Email Template</h3>
		<div class="pull-right box-tools">
			<button data-widget="collapse" type="button" class="btn btn-default btn-sm">
				<i class="fa fa-minus"></i>
			</button>
		</div>
	</div>
	<div class="box-body">
		<p>
			@if($has_template_set)
				{!! nl2br($template) !!}
			@else
				No custom template, using default
			@endif
		</p>
	</div>
	<div class="box-footer">
		<p class="pull-right">
			@if($has_template_set)
				<a href="{{ url('remove_custom_purchase_email/'.$product_id) }}" class="btn btn-warning" type="button" data-method="post" data-confirm="{{ trans('app.are_you_sure') }}">Remove</a>
			@endif
			<button data-target="#productEmailsModal" data-toggle="modal" class="btn btn-secondary" type="button">{{ trans('app.edit') }}</button> &nbsp;
		</p>
	</div>
</div>

<!-- Modal -->
<div class="modal fade" id="productEmailsModal" tabindex="-1" role="dialog" aria-labelledby="productEmailsModalLabel">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="productEmailsModalLabel">Custom Email Template</h4>
			</div>
			<div class="box-body">
				{!! Form::open(['url' => url('save_custom_purchase_email/'.$product_id)]) !!}
				@include('partials.form_errors')
				<div class="form-group">
					{!! Form::label('mail_subject', 'Subject') !!}
					{!! Form::text('mail_subject', $subject, ['class' => 'form-control']) !!}
				</div>
				<div class="form-group">
					{!! Form::label('mail_template', 'Template') !!}
					{!! Form::textarea('mail_template', $template, ['class' => 'form-control']) !!}
				</div>
				<div class="form-group" id="email-template">
					{!! Form::label('bcc_to_admin', 'Send bcc to admin') !!}
					{!! Form::select('bcc_to_admin', ['1' => trans('app.yes'), '0' => trans('app.no')], $bcc, ['class' => 'form-control']) !!}
				</div>
			</div>
			<div class="box-footer">
				{!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
				{!! Form::close() !!}
			</div>
		</div>
	</div>
</div>