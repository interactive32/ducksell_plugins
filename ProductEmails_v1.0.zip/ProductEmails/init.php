<?php
$name = 'Product emails - Custom per product email templates';
$version = '1.0';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
