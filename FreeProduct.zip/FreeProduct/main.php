<?php namespace App\Plugins\FreeProduct;

use App\Http\Controllers\Controller;
use App\Models\Log;
use App\Models\Plugin;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\User;
use App\Services\AmountService;
use App\Services\ManualTransaction;
use App\Services\TemplateService;
use App\Services\Util;
use Auth;
use Event;
use Input;
use Redirect;
use Route;
use Validator;

Event::listen('App\Events\PluginMenu', function($event)
{
    return '<li class="'.(getRouteName() == 'freeproductsetup@setup' ? 'active' : '').'"><a href="'.url('/freeproductsetup').'"><i class="fa fa-gift"></i><span>Free Product</span></a></li>';
});

Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['csrf', 'admin']], function()
    {
        Route::get('freeproductsetup', '\App\Plugins\FreeProduct\FreeProductController@setup');
        Route::post('freeproductsetup', '\App\Plugins\FreeProduct\FreeProductController@update');
    });

    Route::group(['middleware' => ['csrf']], function()
    {
        Route::get('getproduct/{product_id}', '\App\Plugins\FreeProduct\FreeProductController@register');
        Route::post('getproduct/{product_id}', '\App\Plugins\FreeProduct\FreeProductController@submitregistration');
    });

    Route::group(['middleware' => ['customer', 'csrf']], function()
    {
        Route::get('freedownload', '\App\Plugins\FreeProduct\FreeProductController@freedownload');
    });

});


class FreeProductController extends Controller
{
    public $free_products;
    public $template;
    public $mail_subject;

    public function __construct()
    {
        parent::__construct();

        $options = Plugin::getData('free_product');
        $this->free_products = $options->where('key', 'products')->first() ? json_decode($options->where('key', 'products')->first()->value) : [];
        $this->template = $options->where('key', 'mail_template')->first() ? $options->where('key', 'mail_template')->first()->value : "Hi,\n\nThank you for registering.\n\nDownload link: {{ \$download_link }}\n\nRegards,\nThe Team\n";
        $this->mail_subject = $options->where('key', 'mail_subject')->first() ? $options->where('key', 'mail_subject')->first()->value : "Thank you for registering";
    }

    public function setup()
    {
        $products = Product::all();

        return view(basename(__DIR__).'/views/setup')->with([
            'page_title' => trans('app.downloads'),
            'data' => $products,
            'template' => $this->template,
            'free_products' => $this->free_products,
            'mail_subject' => $this->mail_subject,
        ]);
    }

    public function update()
    {
        $rules = [

        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('freeproductsetup')
                ->withErrors($validator)
                ->withInput();
        } else {

            $TemplateService = new TemplateService();
            $TemplateService->setContent(Input::get('mail_template'));
            $TemplateService->setVars(['download_link' => 'http://example.com']);

            if($TemplateService->render() === false) {
                return Redirect::to('freeproductsetup')
                    ->withErrors(trans('app.template_error'))
                    ->withInput();
            }

            $products = [];

            foreach (Input::all() as $key => $value) {
                if(strpos($key, 'product_') !== false && $value == 1) {
                    $products[] = str_replace('product_', '', $key);
                }

            }

            try {
                Plugin::updateValue('free_product', 'mail_template', Input::get('mail_template'));
                Plugin::updateValue('free_product', 'mail_subject', Input::get('mail_subject'));
                Plugin::updateValue('free_product', 'products', json_encode($products));
            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to('freeproductsetup')
                    ->withErrors($e->getMessage())
                    ->withInput();
            }

            flash()->success(trans('app.success'));
            return Redirect::to('freeproductsetup');

        }
    }

    public function register($product_id)
    {
        $product = Product::find($product_id);

        if(!$product || !in_array($product_id, $this->free_products)) {
            return Redirect::to('/');
        }

        return view(basename(__DIR__).'/views/register');
    }

    public function submitregistration($product_id)
    {
        $product = Product::find($product_id);

        if(!$product || !in_array($product_id, $this->free_products)) {
            return Redirect::to('/');
        }

        $rules = [
            'name'				=> 'required',
            'email'				=> 'required|email',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('getproduct/'.$product_id)
                ->withErrors($validator)
                ->withInput();
        } else {

            $User = new User();

            // get existing or create new customer
            $customer = $User->getOrCreateCustomer(Input::get('email'), Input::get('name'), Input::get('email'), [], false);
            if(!$customer) {
                Log::write('log_cannot_create_customer', Input::get('email'));
                return Redirect::to('getproduct/'.$product_id.'?final=1')->withErrors(trans('app.error'));
            }

            $amount = new AmountService();

            $already_bought = false;
            foreach($customer->transactions as $transaction) {

                foreach($transaction->products as $customer_product) {
                    if($customer_product->id == $product->id) {
                        $already_bought = true;
                        break;
                    }
                }

                if($already_bought) {
                    return Redirect::to('getproduct/'.$product_id.'?final=1');
                    break;
                }
            }

            try {

                $ManualTransaction = new ManualTransaction($customer->id, $product->id, $amount, false);
                $ManualTransaction->admin = 'free_product_plugin';
                $ManualTransaction->payment_processor = 'free_product_plugin';
                $transaction = $ManualTransaction->createOrder();

                $template = $this->template;
                $direct_link = url('/freedownload') .'?q='. $transaction->hash;
                $TemplateService = new TemplateService();
                $TemplateService->setContent($template);
                $TemplateService->setVars(['download_link' => $direct_link]);

                Util::sendMail($customer->email, $this->mail_subject, $TemplateService->render());

                flash()->success(trans('app.success'));
                return Redirect::to('getproduct/'.$product_id.'?final=1');
            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to('getproduct/'.$product_id.'?final=1')
                    ->withErrors(trans('app.error'))
                    ->withInput();
            }

        }
    }

    public function freedownload()
    {
        $Transactions = new Transaction();
        $transactions = $Transactions->getDownloads();

        return view(basename(__DIR__).'/views/download')->with([
            'page_title' => trans('app.download'),
            'customer' => Auth::user(),
            'transactions' => $transactions,
            'free_products' => $this->free_products,
        ]);
    }

}
