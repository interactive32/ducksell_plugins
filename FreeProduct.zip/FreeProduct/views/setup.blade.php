@extends('app')

@section('content')

    <section>
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Free Product</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                {!! Form::open() !!}
                                @include('partials.form_errors')
                                <div class="form-group">
                                    {!! Form::label('mail_subject', 'Email subject') !!}
                                    {!! Form::text('mail_subject', $mail_subject, ['class' => 'form-control']) !!}
                                </div>
                                <div class="form-group">
                                    {!! Form::label('mail_template', 'Confirmation email sent after registration') !!}
                                    {!! Form::textarea('mail_template', $template, ['class' => 'form-control']) !!}
                                </div>
                                <hr>
                                @foreach(\App\Models\Product::lists('name', 'id') as $key => $product)
                                <div class="form-group" id="email-template">
                                    {!! Form::label('product_'.$key, $product) !!}
                                    {!! Form::select('product_'.$key, ['1' => 'Set as free product', '0' => trans('app.disabled')], in_array($key, $free_products) ? 1 : 0, ['class' => 'form-control']) !!}
                                    @if(in_array($key, $free_products))
                                        <p>Link to get the product: <a target="_blank" href="{{ url('/getproduct/'.$key) }}">{{ url('/getproduct/'.$key) }}</a></p>
                                    @endif
                                </div>
                                @endforeach
                            </div>
                            <div class="box-footer">
                                {!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
