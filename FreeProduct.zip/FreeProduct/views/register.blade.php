@include('partials.head_minimal')
<body>
{!! $plugins_body_top !!}
<div class="wrapper">
    <section class="content" style="margin-top: 20px">
        <div class="row">
            <div class="col-lg-4 col-lg-offset-4">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Sign up</h3>
                    </div>
                    @if(isset($_GET['final']) && $_GET['final'])
                    <div class="box-body">
                        @if (count($errors) > 0)
                            <h3 class="box-title text-center">Error!</h3>
                            <hr/>
                            <p class="text-center">Something went wrong!</p>
                        @else
                            <h3 class="box-title text-center">Thank you!</h3>
                            <hr/>
                            <p class="text-center">Please check your inbox now.</p>
                        @endif
                    </div>
                    @else
                    <div class="box-body">
                        <h4>You will receive an email with a link after registration.</h4>
                        <br>
                        {!! Form::open() !!}
                        @include('partials.form_errors')
                        <div class="form-group">
                            {!! Form::label('name', trans('app.name')) !!}
                            {!! Form::text('name', null, ['class' => 'form-control']) !!}
                        </div>
                        <div class="form-group">
                            {!! Form::label('email', trans('app.user_email')) !!}
                            {!! Form::text('email', null, ['class' => 'form-control']) !!}
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! Form::submit(trans('app.submit'), array('class' => 'btn btn-primary pull-right')) !!}
                        {!! Form::close() !!}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </section>
</div>
@include('partials.js_minimal')
{!! $plugins_body_bottom !!}
</body>
</html>