<?php
$name = '2Checkout integration';
$version = '2.6';
$author = 'Milos Stojanovic';
$description = 'copyright 2016 interactive32.com';
