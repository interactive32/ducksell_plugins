<?php namespace App\Plugins\CustomInvoice;

use Event;

Event::listen('App\Events\PrintInvoice', function($event)
{
    $currency = $event->currency;
    $transaction = $event->transaction;

    return view(basename(__DIR__).'/invoice')->with([
        'transaction' => $transaction,
        'currency' => $currency,
    ]);

});

