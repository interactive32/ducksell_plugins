@include('partials.head')
<body>
{!! $plugins_body_top !!}
<div class="wrapper">
    <section class="content" style="margin-top: 50px">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">Thank You!</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <h4>We will look over your message and get back to you as soon as possible.</h4>
                            <br><br><br>
                            <p class="text-center">
                                <a class="btn btn-success" href="{{ url('download') }}">Go back</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@include('partials.js_minimal')
{!! $plugins_body_bottom !!}
</body>
</html>
