@include('partials.head')
<body>
{!! $plugins_body_top !!}
<div class="wrapper">
    <section class="content" style="margin-top: 50px">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3">
                <div class="box box-success box-solid">
                    <div class="box-header">
                        <h3 class="box-title">New support ticket</h3>
                    </div>
                    <div class="box-body">
                        <div class="box no-shadow no-border">
                            <div class="box-body">
                                {!! Form::open() !!}
                                @include('partials.form_errors')
                               <div class="form-group">
                                    {!! Form::textarea('text', null, ['class' => 'form-control']) !!}
                               </div>
                            </div>
                            <div class="box-footer">
                                {!! Form::submit('Send', array('class' => 'btn btn-primary pull-right')) !!}
                                {!! Form::close() !!}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
@include('partials.js_minimal')
{!! $plugins_body_bottom !!}
</body>
</html>
