<?php namespace App\Plugins\CustomerSupport;

use App\Http\Controllers\Controller;
use App\Models\Log;
use Auth;
use Event;
use Input;
use Mail;
use Redirect;
use Route;
use Swift_Mailer;
use Swift_Message;
use Validator;

Event::listen('App\Events\ContentBodyBottom', function($event)
{
    if(getRouteName() !== 'download@index') return;

    return '
    <style>
        .need_support {
            position: fixed;
            bottom: -1px;
            right: 150px;
        }
        .need_support .btn {
            right: 100px;
            margin: 0!important;
            border-radius: 4px 4px 0 0!important;
        }route

    </style>

	<div class="need_support"><a href="'.url('support').'" class="btn btn-success">Need Support?</a></div>

    ';
});

Event::listen('App\Events\Routes', function($event)
{
    Route::group(['middleware' => ['customer', 'csrf']], function()
    {
        Route::get('support', '\App\Plugins\CustomerSupport\CustomerSupportController@support');
        Route::get('support_thank_you', '\App\Plugins\CustomerSupport\CustomerSupportController@thankyou');
        Route::post('support', '\App\Plugins\CustomerSupport\CustomerSupportController@post');
    });
});

class CustomerSupportController extends Controller
{

    public function support()
    {
        return view(basename(__DIR__).'/views/support')->with([
            'page_title' => 'Support',
        ]);
    }

    public function post()
    {
        $rules = [
            'text' => 'required',
        ];

        $validator = Validator::make(Input::all(), $rules);

        if ($validator->fails()) {
            return Redirect::to('support')
                ->withErrors($validator)
                ->withInput();
        } else {

            try {
                $body = nl2br(
                    "From: ".Auth::user()->name.
                    "\nEmail: ".Auth::user()->email.
                    "\nCustomer Id: ".Auth::user()->id.
                    "\n========================\n\n".
                    Input::get('text')
                );

                $message = new Swift_Message;
                $message->setTo(config('global.admin-mail'));
                $message->setFrom(Auth::user()->email, Auth::user()->name);
                $message->setReplyTo(Auth::user()->email);
                $message->setSubject('Support Ticket');
                $message->setBody($body, 'text/html');

                $mailer = new Swift_Mailer(Mail::getSwiftMailer()->getTransport());
                $mailer->send($message);

            } catch (\Exception $e) {
                Log::writeException($e);
                return Redirect::to('support')
                    ->withErrors($e->getMessage())
                    ->withInput();
            }

            return Redirect::to('support_thank_you');
        }
    }

    public function thankyou()
    {
        return view(basename(__DIR__).'/views/thankyou')->with([
            'page_title' => 'Support',
        ]);
    }

}